package co.usa.ciclo3.ciclo3.repository.crud;

import co.usa.ciclo3.ciclo3.model.Car;
import co.usa.ciclo3.ciclo3.model.Gama;
import org.springframework.data.repository.CrudRepository;

public interface GamaCrudRepository extends CrudRepository<Gama, Integer> {
}
